import ast
import re
import basic
import scientific as sci
import trigonometric as trig
import constants

_ALLOWED_NAMES = {
    "rt": sci.square_root,
    "cbrt": sci.cube_root,
    "ln": sci.natural_log,
    "log10": sci.log_base_10,
    "log": sci.log_base_n,
    "exp": sci.exponential,
    "sin": trig.sin_deg,
    "cos": trig.cos_deg,
    "tan": trig.tan_deg,
    "asin": trig.asin_deg,
    "acos": trig.acos_deg,
    "atan": trig.atan_deg,
    "pi": constants.PI,
    "e": constants.E,
}

_ALLOWED_NODES = (
    ast.Expression, ast.BinOp, ast.UnaryOp, ast.Call, ast.Name, ast.Load,
    ast.Constant, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Mod, ast.Pow,
    ast.USub, ast.UAdd,
)


def convert_factorials(s: str) -> str:
    while "!" in s:
        idx = s.index("!")
        j = idx - 1
        if j >= 0 and s[j] == ")":
            depth = 1
            k = j - 1
            while k >= 0 and depth > 0:
                if s[k] == ")":
                    depth += 1
                elif s[k] == "(":
                    depth -= 1
                k -= 1
            start = k + 1
            operand = s[start:idx] 
            s = s[:start] + "fact" + operand + s[idx + 1:]
        else:
            k = j
            while k >= 0 and (s[k].isdigit() or s[k] == "."):
                k -= 1
            start = k + 1
            operand = s[start:idx]
            if not operand:
                raise ValueError("'!' must follow a number or parenthesized expression.")
            s = s[:start] + "fact(" + operand + ")" + s[idx + 1:]
    return s


def validate(node, allowed_names):
    if not isinstance(node, _ALLOWED_NODES):
        raise ValueError(f"Disallowed expression element: {type(node).__name__}")

    if isinstance(node, ast.Name) and node.id not in allowed_names:
        raise ValueError(f"Unknown name: '{node.id}'")

    if isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name) or node.func.id not in allowed_names:
            raise ValueError("Only whitelisted functions may be called.")

    for child in ast.iter_child_nodes(node):
        validate(child, allowed_names)


def evaluate(expression: str, ans=None):
    expression = expression.replace("^", "**")

    expression = convert_factorials(expression)

    names = dict(_ALLOWED_NAMES)
    if ans is not None:
        names["ans"] = ans

    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError as e:
        raise ValueError(f"Invalid expression syntax: {e}")

    validate(tree, names)

    code = compile(tree, "<expression>", "eval")
    return eval(code, {"__builtins__": {}}, names)